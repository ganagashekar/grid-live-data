export const environment = {
  production: false,
  // //signalrHubUrl: 'https://localhost:5001/livefeedhub',
  // signalrHubUrl: ' https://localhost:7189/livefeedhub',
  // //signalrHubUrl: 'https://localhost:5001/livefeedhub',
  // //signalrHubUrl: 'http://127.0.0.1:5000/livefeedhub',
  // SignalrAPISaveJson:"https://localhost:7189/WeatherForecast",

//   signalrHubUrl: 'https://127.0.0.1:5001/livefeedhub',
//   //signalrHubUrl: 'https://localhost:7189/livefeedhub',
//  // signalrHubUrl: 'http://127.0.0.1:5000/livefeedhub',
//  SignalrAPISaveJson:"http://127.0.0.1:5000/WeatherForecast",
//  //signalrHubUrl:"http://localhost/StockSignalRServer/livefeedhub"


//  signalrHubUrl: 'https://localhost:7189/livefeedhub',
//   //signalrHubUrl: 'https://localhost:7189/livefeedhub',
//  // signalrHubUrl: 'http://127.0.0.1:5000/livefeedhub',
//  SignalrAPISaveJson:"https://localhost:7189/WeatherForecast",
//  //signalrHubUrl:"http://localhost/StockSignalRServer/livefeedhub"

//signalrHubUrl:  document.location.protocol + "//" + document.location.hostname + ":" + 90 +"/livefeedhub",

// signalrHubUrl: 'http://localhost:90/livefeedhub',
// signalrBreezeHubUrl: 'http://localhost:90/BreezeOperation',

// signalrHubUrl:  document.location.protocol + "//" + document.location.hostname + ":" + 90 +"/livefeedhub",
// signalrBreezeHubUrl: document.location.protocol + "//" + document.location.hostname + ":" + 90 +"/BreezeOperation",

// signalrHubUrl:  document.location.protocol + "//" + document.location.hostname + ":" + 90 +"/livefeedhub",
//   signalrBreezeHubUrl: document.location.protocol + "//" + document.location.hostname + ":" + 90 +"/BreezeOperation",

signalrHubUrl: 'https://localhost:7189/livefeedhub',
signalrBreezeHubUrl: 'https://localhost:7189/BreezeOperation',
//signalrHubUrl: 'https://localhost:7189/livefeedhub',
// signalrHubUrl: 'http://127.0.0.1:5000/livefeedhub',
SignalrAPISaveJson:"//st",
//signalrHubUrl:"http://localhost/StockSignalRServer/livefeedhub"

//  signalrHubUrl:  document.location.protocol + "//" + document.location.hostname + ":" + 90 +"/livefeedhub",
// //signalrHubUrl: 'https://localhost:7189/livefeedhub',
// // signalrHubUrl: 'http://127.0.0.1:5000/livefeedhub',
// SignalrAPISaveJson:"http://172.20.10.7:90/WeatherForecast",
// //signalrHubUrl:"http://localhost/StockSignalRServer/livefeedhub"

};
