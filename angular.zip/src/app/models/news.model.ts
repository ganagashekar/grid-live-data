export interface News {
    id: number;
    title: string;
    imageSource: string;
}
