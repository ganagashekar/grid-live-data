export const newsFeed = [
    {
        id: 0,
        title: 'Crypto bid to buy US constitution copy at action fails',
        imageSource: 'CryptoBid'
    }, {
        id: 1,
        title: 'Crypto adverts on London Tube under investigation',
        imageSource: 'CryptoInvestigation'
    }, {
        id: 2,
        title: 'The Missing Cryptoqueen and ONE COIN',
        imageSource: 'Cryptoqueen'
    }, {
        id: 3,
        title: "LA's Staples Center to be renamed after cryptocurrency firm",
        imageSource: 'StaplesCenter'
    }, {
        id: 4,
        title: 'Squid Game crypto token collapses in apparent scam',
        imageSource: 'SquidGame'
    }, {
        id: 5,
        title: 'Bitcoin: Bank deputy calls for urgent crypto regulation',
        imageSource: 'BitcoinRegulation'
    }, {
        id: 6,
        title: 'Lincolnshire boy has £2m of cryptocurrency seized by police',
        imageSource: 'SeizedCryptocurrency'
    }
];
