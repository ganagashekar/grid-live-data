export const environment = {
  production: false,
  // //signalrHubUrl: 'https://localhost:5001/livefeedhub',
  // signalrHubUrl: ' https://localhost:7189/livefeedhub',
  // //signalrHubUrl: 'https://localhost:5001/livefeedhub',
  // //signalrHubUrl: 'http://127.0.0.1:5000/livefeedhub',
  // SignalrAPISaveJson:"https://localhost:7189/WeatherForecast",

//   signalrHubUrl: 'https://127.0.0.1:5001/livefeedhub',
//   //signalrHubUrl: 'https://localhost:7189/livefeedhub',
//  // signalrHubUrl: 'http://127.0.0.1:5000/livefeedhub',
//  SignalrAPISaveJson:"http://127.0.0.1:5000/WeatherForecast",
//  //signalrHubUrl:"http://localhost/StockSignalRServer/livefeedhub"


//  signalrHubUrl: 'https://localhost:7189/livefeedhub',
//   //signalrHubUrl: 'https://localhost:7189/livefeedhub',
//  // signalrHubUrl: 'http://127.0.0.1:5000/livefeedhub',
//  SignalrAPISaveJson:"https://localhost:7189/WeatherForecast",
//  //signalrHubUrl:"http://localhost/StockSignalRServer/livefeedhub"

signalrHubUrl: 'http://192.168.0.106:90/livefeedhub',
//signalrHubUrl: 'https://localhost:7189/livefeedhub',
// signalrHubUrl: 'http://127.0.0.1:5000/livefeedhub',
SignalrAPISaveJson:"http://192.168.0.106:90/WeatherForecast",
//signalrHubUrl:"http://localhost/StockSignalRServer/livefeedhub"

};
