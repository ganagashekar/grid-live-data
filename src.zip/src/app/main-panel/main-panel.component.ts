import { Component, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'main-panel',
    templateUrl: './main-panel.component.html',
    styleUrls: ['./main-panel.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class MainPanelComponent {}
